simplex-algorithm
=================

Python source code for [Linear Programming and the Simplex Algorithm](http://jeremykun.com/2014/12/01/linear-programming-and-the-simplex-algorithm/)
